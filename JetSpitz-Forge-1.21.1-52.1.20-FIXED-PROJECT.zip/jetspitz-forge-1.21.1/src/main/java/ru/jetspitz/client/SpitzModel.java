package ru.jetspitz.client;

import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import ru.jetspitz.JetSpitzMod;
import ru.jetspitz.entity.FlyingSpitzEntity;

public class SpitzModel extends HierarchicalModel<FlyingSpitzEntity> {
    public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
            ResourceLocation.fromNamespaceAndPath(JetSpitzMod.MOD_ID, "flying_spitz"), "main");

    private final ModelPart root;
    private final ModelPart head;
    private final ModelPart frontLeftLeg;
    private final ModelPart frontRightLeg;
    private final ModelPart backLeftLeg;
    private final ModelPart backRightLeg;
    private final ModelPart tail;
    private final ModelPart rotor;

    public SpitzModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.frontLeftLeg = root.getChild("front_left_leg");
        this.frontRightLeg = root.getChild("front_right_leg");
        this.backLeftLeg = root.getChild("back_left_leg");
        this.backRightLeg = root.getChild("back_right_leg");
        this.tail = root.getChild("tail");
        this.rotor = root.getChild("rotor");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Fluffy Pomeranian body and rounded head.
        root.addOrReplaceChild("body", CubeListBuilder.create()
                .texOffs(0, 0).addBox(-4.2F, -3.8F, -5.5F, 8.4F, 7.6F, 11.0F),
                PartPose.offset(0.0F, 15.0F, 0.0F));

        PartDefinition head = root.addOrReplaceChild("head", CubeListBuilder.create()
                .texOffs(0, 28).addBox(-4.0F, -3.8F, -4.2F, 8.0F, 7.6F, 7.0F),
                PartPose.offset(0.0F, 12.3F, -5.2F));
        head.addOrReplaceChild("muzzle", CubeListBuilder.create()
                .texOffs(46, 36).addBox(-2.1F, -1.15F, -2.3F, 4.2F, 2.5F, 2.6F),
                PartPose.offset(0.0F, 1.3F, -1.6F));
        head.addOrReplaceChild("left_ear", CubeListBuilder.create()
                .texOffs(40, 0).addBox(-1.2F, -3.3F, -1.0F, 2.4F, 3.8F, 2.2F),
                PartPose.offset(-2.6F, -2.5F, 0.5F));
        head.addOrReplaceChild("right_ear", CubeListBuilder.create()
                .texOffs(40, 0).addBox(-1.2F, -3.3F, -1.0F, 2.4F, 3.8F, 2.2F),
                PartPose.offset(2.6F, -2.5F, 0.5F));
        head.addOrReplaceChild("left_eye", CubeListBuilder.create()
                .texOffs(54, 40).addBox(-0.45F, -0.45F, -0.10F, 0.9F, 0.9F, 0.35F),
                PartPose.offset(-2.0F, 0.2F, -4.05F));
        head.addOrReplaceChild("right_eye", CubeListBuilder.create()
                .texOffs(54, 40).addBox(-0.45F, -0.45F, -0.10F, 0.9F, 0.9F, 0.35F),
                PartPose.offset(2.0F, 0.2F, -4.05F));

        root.addOrReplaceChild("front_left_leg", leg(), PartPose.offset(-2.8F, 17.1F, -3.5F));
        root.addOrReplaceChild("front_right_leg", leg(), PartPose.offset(2.8F, 17.1F, -3.5F));
        root.addOrReplaceChild("back_left_leg", leg(), PartPose.offset(-2.8F, 17.1F, 3.6F));
        root.addOrReplaceChild("back_right_leg", leg(), PartPose.offset(2.8F, 17.1F, 3.6F));

        root.addOrReplaceChild("tail", CubeListBuilder.create()
                .texOffs(0, 48).addBox(-1.35F, -1.0F, -0.5F, 2.7F, 2.7F, 5.0F),
                PartPose.offset(0.0F, 13.8F, 5.0F));

        // Backpack with two fuel tanks.
        PartDefinition pack = root.addOrReplaceChild("jetpack", CubeListBuilder.create()
                .texOffs(0, 36).addBox(-3.6F, -2.2F, -2.4F, 7.2F, 4.5F, 5.2F),
                PartPose.offset(0.0F, 9.8F, 1.0F));
        pack.addOrReplaceChild("left_tank", CubeListBuilder.create()
                .texOffs(20, 36).addBox(-1.0F, -2.0F, -1.1F, 2.0F, 4.0F, 2.2F),
                PartPose.offset(-3.8F, 0.0F, 0.0F));
        pack.addOrReplaceChild("right_tank", CubeListBuilder.create()
                .texOffs(20, 36).addBox(-1.0F, -2.0F, -1.1F, 2.0F, 4.0F, 2.2F),
                PartPose.offset(3.8F, 0.0F, 0.0F));

        // Twin little miniguns attached beside the front paws.
        addGun(root, "left_gun", -5.0F, 15.0F, -4.4F);
        addGun(root, "right_gun", 5.0F, 15.0F, -4.4F);

        PartDefinition rotor = root.addOrReplaceChild("rotor", CubeListBuilder.create()
                .texOffs(24, 48).addBox(-0.7F, -3.3F, -0.7F, 1.4F, 1.7F, 1.4F)
                .texOffs(32, 48).addBox(-5.0F, -3.7F, -0.45F, 10.0F, 0.7F, 0.9F),
                PartPose.offset(0.0F, 7.6F, 1.0F));
        rotor.addOrReplaceChild("rotor_cross", CubeListBuilder.create()
                .texOffs(32, 50).addBox(-0.45F, -3.7F, -5.0F, 0.9F, 0.7F, 10.0F),
                PartPose.ZERO);

        return LayerDefinition.create(mesh, 64, 64);
    }

    private static CubeListBuilder leg() {
        return CubeListBuilder.create().texOffs(32, 0)
                .addBox(-1.45F, -0.2F, -1.45F, 2.9F, 5.0F, 2.9F);
    }

    private static void addGun(PartDefinition root, String name, float x, float y, float z) {
        PartDefinition gun = root.addOrReplaceChild(name, CubeListBuilder.create()
                .texOffs(32, 36).addBox(-1.25F, -1.15F, -2.1F, 2.5F, 2.3F, 4.6F),
                PartPose.offset(x, y, z));
        gun.addOrReplaceChild("barrels", CubeListBuilder.create()
                .texOffs(48, 48).addBox(-1.05F, -0.9F, -3.4F, 2.1F, 1.8F, 1.8F), PartPose.ZERO);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(FlyingSpitzEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        this.head.xRot = headPitch * ((float) Math.PI / 180F);
        float flap = Mth.cos(limbSwing * 0.65F) * 0.48F * limbSwingAmount;
        this.frontLeftLeg.xRot = flap - 0.25F;
        this.frontRightLeg.xRot = -flap - 0.25F;
        this.backLeftLeg.xRot = -flap + 0.20F;
        this.backRightLeg.xRot = flap + 0.20F;
        this.tail.xRot = -0.45F;
        this.tail.yRot = Mth.sin(ageInTicks * 0.17F) * 0.28F;
        this.rotor.yRot = ageInTicks * 1.75F;
    }
}
