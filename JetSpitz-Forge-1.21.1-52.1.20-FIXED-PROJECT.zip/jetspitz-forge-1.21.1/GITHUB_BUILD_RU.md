# Сборка Jet Spitz через GitHub Actions

Проект рассчитан на Minecraft 1.21.1, Forge 52.1.20 и Java 21.

## Важно: GitHub должен видеть распакованные файлы

Загрузка ZIP в корень репозитория сама по себе не запускает сборку. В корне репозитория должны лежать `build.gradle`, `settings.gradle`, `gradle.properties`, папка `src` и файл `.github/workflows/build.yml`.

## Как подготовить репозиторий

1. Распакуйте `forge-1.21.1-52.1.20-mdk.zip` в отдельную папку.
2. Распакуйте архив Jet Spitz рядом.
3. Скопируйте из папки `jetspitz-forge-1.21.1` в папку распакованного MDK файлы `build.gradle`, `settings.gradle`, `gradle.properties`, папки `src` и `.github` (с заменой одноимённых файлов).
4. Не удаляйте из MDK `gradlew`, `gradlew.bat` и `gradle/wrapper/gradle-wrapper.jar`. В `gradle/wrapper/gradle-wrapper.properties` должна быть строка с Gradle 8.12.1: `distributionUrl=https\://services.gradle.org/distributions/gradle-8.12.1-bin.zip`.
5. Загрузите содержимое подготовленной папки MDK в корень репозитория GitHub и выполните Commit changes. Не загружайте только ZIP.
6. Откройте вкладку Actions → `Build Jet Spitz` → последний запуск. После `success` скачайте артефакт `JetSpitz-Forge-1.21.1-52.1.20`. Внутри будет JAR.

## Локальная сборка

В каталоге проекта выполните `./gradlew clean build` (на Android терминале при необходимости: `bash gradlew clean build`). JAR появится в `build/libs/jetspitz-1.0.0.jar`.

Если сборка выдаёт ошибку, сохраните полный текст начиная с `* What went wrong:` и прикрепите его — по одной строке `BUILD FAILED` причину определить нельзя.
