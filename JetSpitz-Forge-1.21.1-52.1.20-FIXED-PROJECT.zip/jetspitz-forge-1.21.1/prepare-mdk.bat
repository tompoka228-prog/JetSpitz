@echo off
setlocal
if "%~1"=="" (
  echo Usage: prepare-mdk.bat C:\path\to\extracted\forge-mdk
  exit /b 2
)
set "SOURCE_DIR=%~dp0"
set "MDK_DIR=%~1"
if not exist "%MDK_DIR%\gradlew.bat" (
  echo gradlew.bat not found in MDK folder.
  exit /b 2
)
if not exist "%MDK_DIR%\gradle\wrapper\gradle-wrapper.jar" (
  echo gradle-wrapper.jar not found in MDK folder.
  exit /b 2
)
copy /Y "%SOURCE_DIR%build.gradle" "%MDK_DIR%\build.gradle" >nul
copy /Y "%SOURCE_DIR%settings.gradle" "%MDK_DIR%\settings.gradle" >nul
copy /Y "%SOURCE_DIR%gradle.properties" "%MDK_DIR%\gradle.properties" >nul
if exist "%MDK_DIR%\src" rmdir /S /Q "%MDK_DIR%\src"
xcopy /E /I /Y "%SOURCE_DIR%src" "%MDK_DIR%\src" >nul
if not exist "%MDK_DIR%\.github\workflows" mkdir "%MDK_DIR%\.github\workflows"
copy /Y "%SOURCE_DIR%.github\workflows\build.yml" "%MDK_DIR%\.github\workflows\build.yml" >nul
powershell -NoProfile -Command "$p='%MDK_DIR%\gradle\wrapper\gradle-wrapper.properties'; if(Test-Path $p){(Get-Content $p) -replace 'distributionUrl=.*','distributionUrl=https\://services.gradle.org/distributions/gradle-8.12.1-bin.zip' | Set-Content $p -Encoding ASCII}"
echo Jet Spitz sources installed. Run: cd /d "%MDK_DIR%" ^& gradlew.bat clean build
endlocal
