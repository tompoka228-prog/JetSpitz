# Проверка проекта Jet Spitz

В исходном архиве обнаружены и исправлены следующие проблемы:

1. `FlyingSpitzEntity.java` использовал `ParticleTypes.CRIT`, но не импортировал `net.minecraft.core.particles.ParticleTypes` — исправлено.
2. Для свободного перемещения использовалась наземная `RandomStrollGoal`, хотя сущность имеет `FlyingMoveControl` и `FlyingPathNavigation`. Заменено на `WaterAvoidingRandomFlyingGoal`, который предназначен для воздушного блуждания летающих существ.
3. Входная точка мода вызывала устаревший `FMLJavaModLoadingContext.get()`. Переведено на рекомендованную для Forge 1.21.1 передачу `FMLJavaModLoadingContext` в конструктор.
4. Сборка в workflow переключена на Gradle 8.12.1 и `clean build`.
5. Частота очередей миниганов смягчена до примерно 3,3 очередей в секунду; визуальные вспышки разнесены на два ствола.

Проверено статически: JSON-файлы разбираются, структура ресурсов совпадает с mod id `jetspitz`, в build-конфигурации указаны Minecraft 1.21.1, Forge 52.1.20 и Java 21.

**Ограничение проверки:** компиляцию ForgeGradle здесь выполнить не получилось: в среде нет Gradle, а DNS-доступ к `services.gradle.org` и `maven.minecraftforge.net` заблокирован. Поэтому исходники исправлены, но успешная компиляция и запуск в Minecraft ещё не подтверждены. Не считайте этот архив готовым JAR-файлом.
