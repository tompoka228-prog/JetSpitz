#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: bash prepare-mdk.sh /path/to/extracted/forge-mdk" >&2
  exit 2
fi

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
MDK_DIR="$1"
if [[ ! -d "$MDK_DIR" ]]; then
  echo "MDK directory not found: $MDK_DIR" >&2
  exit 2
fi
if [[ ! -f "$MDK_DIR/gradlew" || ! -f "$MDK_DIR/gradle/wrapper/gradle-wrapper.jar" ]]; then
  echo "This is not a complete extracted Forge MDK: gradlew or gradle-wrapper.jar is missing." >&2
  exit 2
fi

cp "$SOURCE_DIR/build.gradle" "$SOURCE_DIR/settings.gradle" "$SOURCE_DIR/gradle.properties" "$MDK_DIR/"
rm -rf "$MDK_DIR/src"
cp -R "$SOURCE_DIR/src" "$MDK_DIR/src"
mkdir -p "$MDK_DIR/.github/workflows"
cp "$SOURCE_DIR/.github/workflows/build.yml" "$MDK_DIR/.github/workflows/build.yml"

WRAPPER_PROPS="$MDK_DIR/gradle/wrapper/gradle-wrapper.properties"
if [[ -f "$WRAPPER_PROPS" ]]; then
  sed -i -E 's#distributionUrl=.*#distributionUrl=https\\://services.gradle.org/distributions/gradle-8.12.1-bin.zip#' "$WRAPPER_PROPS"
fi

echo "Jet Spitz sources installed into: $MDK_DIR"
echo "Build with: cd "$MDK_DIR" && bash gradlew clean build"
