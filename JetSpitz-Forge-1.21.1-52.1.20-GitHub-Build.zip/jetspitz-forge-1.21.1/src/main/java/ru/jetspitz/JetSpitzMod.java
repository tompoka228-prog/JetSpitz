package ru.jetspitz;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import ru.jetspitz.entity.FlyingSpitzEntity;
import ru.jetspitz.registry.ModEntities;

@Mod(JetSpitzMod.MOD_ID)
public class JetSpitzMod {
    public static final String MOD_ID = "jetspitz";

    public JetSpitzMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITY_TYPES.register(modBus);
        modBus.addListener(this::registerSpawnPlacements);
        modBus.addListener(this::createAttributes);
    }

    private void registerSpawnPlacements(SpawnPlacementRegisterEvent event) {
        event.register(
                ModEntities.FLYING_SPITZ.get(),
                SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                FlyingSpitzEntity::checkSpitzSpawnRules,
                SpawnPlacementRegisterEvent.Operation.OR
        );
    }

    private void createAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.FLYING_SPITZ.get(), Mob.createMobAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 24.0D)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, 0.28D)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FLYING_SPEED, 0.48D)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE, 24.0D)
                .build());
    }
}
