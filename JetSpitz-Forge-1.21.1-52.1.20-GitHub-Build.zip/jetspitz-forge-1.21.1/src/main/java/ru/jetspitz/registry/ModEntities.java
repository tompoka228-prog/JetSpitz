package ru.jetspitz.registry;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import ru.jetspitz.JetSpitzMod;
import ru.jetspitz.entity.FlyingSpitzEntity;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, JetSpitzMod.MOD_ID);

    public static final RegistryObject<EntityType<FlyingSpitzEntity>> FLYING_SPITZ =
            ENTITY_TYPES.register("flying_spitz", () -> EntityType.Builder
                    .of(FlyingSpitzEntity::new, MobCategory.CREATURE)
                    .sized(0.82F, 0.78F)
                    .clientTrackingRange(10)
                    .updateInterval(2)
                    .build("flying_spitz"));

    private ModEntities() {}
}
