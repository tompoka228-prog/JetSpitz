package ru.jetspitz.client;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;
import ru.jetspitz.JetSpitzMod;
import ru.jetspitz.entity.FlyingSpitzEntity;

public class SpitzRenderer extends MobRenderer<FlyingSpitzEntity, SpitzModel> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath(
            JetSpitzMod.MOD_ID, "textures/entity/flying_spitz.png");

    public SpitzRenderer(EntityRendererProvider.Context context) {
        super(context, new SpitzModel(context.bakeLayer(SpitzModel.LAYER_LOCATION)), 0.38F);
    }

    @Override
    public ResourceLocation getTextureLocation(FlyingSpitzEntity entity) {
        return TEXTURE;
    }
}
